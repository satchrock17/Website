import tkinter as tk            # Nur für das GUI
from tkinter import ttk

# Erzeugen der Arrays
größeMatrix = 40                
anzVerschiedenerEingaben = 30
buchstaben = ["" for _ in range(größeMatrix)]
matrix = [[[0 for _ in range(anzVerschiedenerEingaben)] for _ in range(größeMatrix)] for _ in range(größeMatrix)]
fertigeMatrix = [[0 for _ in range(größeMatrix)] for _ in range(größeMatrix)]

b = []
konflikte = []
zyklus = False
konfliktweg = []
a = 0
buchstabenAnzahl = 0
kette = ""



# Funktionen zum Einfügen neuer Werte in die Matrix
def buchstabenEinfuegen(name):
    "Fügt einen Buchstaben als neuen Knoten in den Graphen / die Matrix ein"
    global buchstabenAnzahl
    if buchstabenAnzahl < len(buchstaben):
        buchstaben[buchstabenAnzahl] = name
        buchstabenAnzahl += 1

def index(name):
    "Gibt den Index eines Buchstabens im Array 'buchstaben' zurück"
    j = 0
    for i in buchstaben:
        if i == name:
            return j
        else:
            j += 1
    return -2

def neuesGewicht(leichter, schwerer):
    "Fügt eine neue Verbindung in den Graphen / die Matrix zwischen zwei Punkten ein"
    x = index(leichter)
    y = index(schwerer)
    if x == -2 or y == -2:
        print("index nicht verfügbar")
    else:
        if x != y:
            if matrix[x][y][a] == -1 or matrix[x][y][a] == 1:
                matrix[x][y][a] = 0
                matrix[y][x][a] = 0
            if matrix[x][y][a] == 0:
                matrix[x][y][a] = 1
                matrix[y][x][a] = -1

def vervollständigen(o, t):
    "Vervollständigt die Matrix, ergänzt fehlende Verbindungen (Wenn a < b < c, dann gilt auch a < c)" 
    global b
    global a
    for i in range(größeMatrix):
        if matrix[o][i][a] == 1:  
            if i not in b:  
                b.append(i)
                vervollständigen(i, 1) 
    if t == 0:
        for i in b:
            if matrix[o][i][a] == 0:
                if o != i:
                    fertigeMatrix[o][i] = 1  
                    fertigeMatrix[i][o] = -1  
        b = []  

def matrixAbschließen():
    "Überführt alle Ergebnisse aus der 3-dimensionalen Matrix in ein 2-dimensionales, fertiges Array."
    global fertigeMatrix
    global konflikte
    for i in range (größeMatrix):
        for j in range(größeMatrix):
            for k in range(anzVerschiedenerEingaben):
                if matrix[i][j][k] != 0:
                    if (fertigeMatrix[i][j] > 0 and matrix[i][j][k] < 0 or fertigeMatrix[i][j] < 0 and matrix[i][j][k] > 0):
                        if i not in konflikte:
                            konflikte.append(i)
                        if j not in konflikte:
                            konflikte.append(j)
                    fertigeMatrix[i][j] += matrix[i][j][k]
                    if fertigeMatrix[i][j] >= 1:
                        fertigeMatrix[i][j] = 1
                    if fertigeMatrix[i][j] <= -1:
                        fertigeMatrix[i][j] = -1
    for i in konflikte:
        konfliktErkennen([], i)
    global konfliktweg
    for i in konfliktweg:
        konfliktLösen(i)
    label.config(text="Welche Aufgaben möchten sie sortiert haben?")
    eingabe.destroy()
    label2.destroy()
    knopf.destroy()
    einfuegen.destroy()
    eingabe2.pack()
    auswahlKnopf.pack()

def eingabeSpeichern():
    "Liest die Eingabe im GUI ein und fügt diese in eine neue Ebene der Matrix ein."
    global a
    if eingabe.get() != "":
        kette = eingabe.get()
        kette = kette.upper()
        kette = kette.replace(" ", "")
        kette = kette.replace("<", "")
        i = 0
        for i in kette:
            if i not in buchstaben:
                buchstabenEinfuegen(i)
        for j in range(len(kette) - 1):
            neuesGewicht(kette[j], kette[j+1])
        for i in range(größeMatrix):
            vervollständigen(i, 0)
        a += 1

def konsolenAusgabe():
    "Druckt die Buchstaben und Matrix in die Konsole. Sie dient nur zu Debug-Zwecken und wird deshalb nicht aufgerufen."
    print(buchstaben)
    for x in range(anzVerschiedenerEingaben):
        for i in range(größeMatrix):
            for j in range(größeMatrix):
                print(matrix[i][j][x], end=" | ")
            print()

def vervollständigteMatrixAusgeben():
    "Gibt die vervollständigte Matrix in die Konsole aus. Sie dient nur zu Debug-Zwecken und wird deshalb nicht aufgerufen."
    for i in range(größeMatrix):
        for j in range(größeMatrix):
            print(fertigeMatrix[i][j], end=" | ")
        print()

# Funktionen zum Umgang mit Konflikten
def konfliktErkennen(weg, a):
    "Ein Suchalgorithmus, um alle beteiligten Buchstaben in einem Konflikt zu erkennen."
    weg.append(a)
    global konflikte
    global zyklus
    if not zyklus:
        for i in range (größeMatrix):
            
            if fertigeMatrix[a][i] == 1:
                if i in konflikte and i != konflikte[0]:
                    weg.append(i)
                    global konfliktweg; konfliktweg.append(weg)
                    zyklus = True
                else:
                    konfliktErkennen(weg, i)

def konfliktLösen(beteiligteBuchstaben):
    "Setzt alle an einem Konflikt beteiligte Klausuren gleich"
    for i in beteiligteBuchstaben:
        for j in beteiligteBuchstaben:
            if i != j:
                fertigeMatrix[i][j] = 0
                fertigeMatrix[j][i] = 0


    
# Anzeigen und sortieren der Ergebnisse
def klausurenSortieren():
    "Sortiert die eingegebenen Klausuren nach ihrer Schwierigkeit und gibt sie im GUI aus."
    stufe = 0
    reihe = []
    if eingabe2.get() != "":
        kette = eingabe2.get()
        kette = kette.upper()
        kette = kette.replace(" ", "")
        kette = kette.replace("<", "")
        for i in kette:
            s = index(i)
            if s != -2:
                for j in range(größeMatrix):
                    stufe += fertigeMatrix[j][s]
                reihe.append([i, stufe])
                stufe = 0
    reihe = sorted(reihe, key=lambda x: x[1])
    print(reihe)
    buchstab = [i[0] for i in reihe]
    ergebnis = tk.Label(master=fenster, text = " < ".join(buchstab)).pack()
    einfuegen.destroy()
                


# Elemente für das GUI
fenster = tk.Tk()
fenster.title("Sortieren alter Klausuren")

label = tk.Label(master = fenster, text = "Geben sie alle Aufgaben in der richtigen Reihenfolge ein. Die leichteste Klausur ganz links und die schwerste ganz rechts.")
label.pack()

label2 = tk.Label(master= fenster, text = "Das Zeichen '<' spielt dabei keine Rolle:")
label2.pack()

eingabe = tk.Entry(fenster)
eingabe.pack()

einfuegen = ttk.Button(master=fenster, text="Eingabe abspeichern", command=eingabeSpeichern)
einfuegen.pack()

knopf = ttk.Button(master = fenster, text = "Zur Auswahl der Aufgaben", command = matrixAbschließen)
knopf.pack()



eingabe2 = tk.Entry(fenster)
auswahlKnopf = ttk.Button(master=fenster, text = "Sortieren", command = klausurenSortieren)

fenster.mainloop()